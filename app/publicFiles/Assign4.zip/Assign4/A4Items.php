<!DOCTYPE html>
<html>
<?php 
//connects to mySQL server
require("login.php"); 
 
//preps mySQL statment
$stmt = $conn->prepare("SELECT id, name, description, price, barcode, qty from item;;");
$stmt->execute();
?>
<head>
	<title>Items</title>
	<link rel="shortcut icon" type="image/x-icon" href="favicon.ico" />
	<link href="https://fonts.googleapis.com/css?family=Abel" rel="stylesheet">
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.1/css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="A4Items.css">
</head>
<body>
	<nav class="navbar navbar-default">
		<div class="navbar-collapse collapse w-100 order-1 order-md-0 dual-collapse2">
			<a href="A4Home.html" class="navbar-left"><img src="icon.png" id="icon"></a>
      		<ul class="nav navbar-nav">
				<li><a href="A4Home.html" id="home">Dashboard</a></li>
    		</ul>
    		<ul class="nav navbar-nav navbar-right">
        		<li><a href="A4Login.html" id="log">Logoff</a></li>
    		</ul>
   		</div>
	</nav>

	<h1 id="title">View, modify or create items</h1>

	<p>To modify an item, select their name from the following list and click the 'modify' button to the right.</p>
	<p>To create an item, simply click the 'create' button below.</p>

	<!--Redirects to the "Create item form-->"
	<a class="btn btn-info" href="A4NewItem.php" role="button">Create New Item</a>
	<!--These two buttons will perform the functions within the table that displays data using sql-->
	<form action="A4UpdateItem.php" method="post">
	<button type="submit" class="btn btn-info" id="tbl">Modify Selected</button>
	<br>
	<br>
	<table>
		<tr>
			<th>Select</th>
			<th> Name </th>
			<th> Description </th>
			<th> Price </th> 
			<th> Quantity </th>
           		
		</tr>
     
		<?php
		//creates table 
		while (list($itemid, $name, $description, $price, $barcode, $qty) = $stmt->fetch(PDO::FETCH_NUM)){
			echo ("<tr>");
			
			echo ("<td>");
			echo("<input type='radio' name='id' value=$itemid checked='checked'>");
			echo ("</td>");
		 
			//Checkbox
			echo ("<td>");
			echo("$name");
			echo ("</td>");
         
			//Name
			echo ("<td>"); 
			echo ($description);
			echo ("</td>");
     
			//Address
			echo ("<td>"); 
			echo ($price);
			echo ("</td>");
     
			
			//phone
			echo ("<td>"); 
			echo ($qty);
			echo ("</td>");
			
		echo("</tr>");
		}
		?>
     
    </form>
</table>
</body>
</html>
