<?php 
//connects to mySQL server
require("login.php"); 
session_start();
 
//preps mySQL statment
$stmt = $conn->prepare("SELECT customer.id, name,  aline1, city, state, zipcode, contactPhone from customer, customer_address, address WHERE address.id=customer_address.addressid AND customer.id=customer_address.customerid AND customer_address.type='Billing';");
$stmt->execute();
?>
<!DOCTYPE html>
<html>
<head>
	<title>Customers</title>
	<link rel="shortcut icon" type="image/x-icon" href="favicon.ico" />
	<link href="https://fonts.googleapis.com/css?family=Abel" rel="stylesheet">
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.1/css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="A4Customers.css">
</head>
<body>

	<nav class="navbar navbar-default">
		<div class="navbar-collapse collapse w-100 order-1 order-md-0 dual-collapse2">
			<a href="A4Home.html" class="navbar-left"><img src="icon.png" id="icon"></a>
      		<ul class="nav navbar-nav">
				<li><a href="A4Home.html" id="home">Dashboard</a></li>
    		</ul>
    		<ul class="nav navbar-nav navbar-right">
        		<li><a href="A4Login.html" id="log">Logoff</a></li>
    		</ul>
   		</div>
	</nav>

	<h1 id="title">View, modify or create customers</h1>
	<p>To modify a customer, select their name from the following list and click the 'modify' button to the right.</p>
	<p>To create a customer, simply click the 'create' button below.</p>

	<!--Redirects to the "Create customer form-->"
	<a class="btn btn-info" href="A4NewCust.php" role="button">Create New Customer</a>
	<!--These two buttons will perform the functions within the table that displays data using sql-->
	
	
	<form action="A4ModifyCust.php" method="post">
	<button type="submit" class="btn btn-info" id="tbl" name="update_button" style="margin-right: 150px;">Edit Selected</button>
	<table>
    <tr>
        <th> Select</th>
        <th> Company Name </th>
        <th> Address </th>
        <th> Phone Number </th> 
    </tr>
     
    <?php
    //creates table 
    while (list($customerid, $name, $aline1, $city, $state, $zipcode, $phone) = $stmt->fetch(PDO::FETCH_NUM)){
        echo ("<tr>");
         
        //Checkbox
        echo ("<td>");
        echo("<input type='radio' name='id' value=$customerid checked='checked'>");
        echo ("</td>");
         
        //Name
        echo ("<td>"); 
        echo ($name);
        echo ("</td>");
     
        //Address
        echo ("<td>"); 
        echo ("$aline1, $city $state $zipcode");
        echo ("</td>");
     
        //phone
        echo ("<td>"); 
        echo ("$phone");
        echo ("</td>");
        
		echo("</tr>");
    }
    ?>
    
    
</table>
  </form>
</body>
</html>