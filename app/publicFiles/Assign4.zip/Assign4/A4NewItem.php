<!DOCTYPE html>
<html>
<head>
	<link href="https://fonts.googleapis.com/css?family=Abel" rel="stylesheet"> 
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.1/css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="A4NewItem.css">
	<link rel="shortcut icon" type="image/x-icon" href="favicon.ico" />
	<title>Create new item</title>
</head>
<body>
	<nav class="navbar navbar-default">
		<div class="navbar-collapse collapse w-100 order-1 order-md-0 dual-collapse2">
			<a href="A4Home.html" class="navbar-left"><img src="icon.png" id="icon"></a>
      		<ul class="nav navbar-nav">
				<li><a href="A4Home.html" id="home">Dashboard</a></li>
    		</ul>
    		<ul class="nav navbar-nav navbar-right">
        		<li><a href="A4Login.html" id="log">Logoff</a></li>
    		</ul>
   		</div>
	</nav>

	<h1>Create new item</h1>
 <?php 
	//connects to mySQL server
	require("login.php");
	if (!empty($_POST)){
	//sets variables equal to passed in $_POST statements
	$itemName = $_POST["itemName"];
	$itemDescription = $_POST["itemDescription"];
	$itemQty = $_POST["itemQty"];
	$itemVendor = $_POST["itemVendor"];
	$itemPrice = $_POST["itemPrice"];
	$itemLocation = $_POST["itemLocation"];
	
	//Creating INSERT STATEMENT for Customer 
	$insert = $conn->prepare("INSERT INTO item(name, description, qty, price) VALUES (:name, :description, :qty, :price);"); 	
	//Binds values for insert statement for Customer
	$insert->bindValue(':name', $itemName, PDO::PARAM_STR);
	$insert->bindValue(':description', $itemDescription, PDO::PARAM_STR); 
	$insert->bindValue(':qty', $itemQty, PDO::PARAM_STR); 
	$insert->bindValue(':price', $itemPrice, PDO::PARAM_STR); 
	 
	
	//if the form has been submitted
	
		//boolean for insert statement
		$testInsert = true;
		//unless each value is filled, gets an error message
		foreach ($_POST as $key => $value)
		{ 
			if (empty($value))
			{
			//ELLY: make the text boxes turn red or something to indicate forms weren't filled in.
				echo("Error: $key is empty. Please fill $key in. <br>");
				$testInsert = false;
			}
		}
		if ($testInsert == true ) //if all values have been filled out.
		{
			try
			{ 
			  $insert->execute();
			  $itemID = $conn->lastInsertId();
			} 
			catch(PDOException $e)
			{
			  echo "Execute failed: " . $e->getMessage();
			}
			
			$insert = $conn->prepare("INSERT INTO item_location VALUES (:itemID, :locationID);"); 
			$insert->bindValue(":itemID", $itemID, PDO::PARAM_INT);
			$insert->bindValue(":locationID", $itemLocation, PDO::PARAM_INT);
			try
			{ 
			  $insert->execute();
			} 
			catch(PDOException $e)
			{
			  echo "Execute failed | item location insert: " . $e->getMessage();
			}
			
			$insert = $conn->prepare("INSERT INTO item_vendor VALUES (:itemID, :vendorID);"); 
			$insert->bindValue(":itemID", $itemID, PDO::PARAM_INT);
			$insert->bindValue(":vendorID", $itemVendor, PDO::PARAM_INT);
			try
			{ 
			  $insert->execute();
			} 
			catch(PDOException $e)
			{
			  echo "Execute failed | item location insert: " . $e->getMessage();
			}
			
			echo "<h2> Item $itemName has been successfully added to the database <br></h2>";
		}
		
	}?>
	<form class="form-inline" id="userForm" action="A4NewItem.php" method="post">
		<div class="container">
			<div class="row">
				<div class="col-sm-3" id="labels">
					<label for="iNam" id="iName" style="margin-top: 5px;">Item Name</label>
					<br>
					<label for="vNam" id="vName" style="margin-top: 25px;">Item Vendor</label>
					<br>
					<label for="iPrice" id="iPric" style="margin-top: 25px;">Item Price</label>
					<br>
					<label for="iHand" id="iQHand" style="margin-top: 25px;">Quantity on hand</label>
					<br>
					<label for="iDes" id="iDesc" style="margin-top: 25px;">Item Description</label>
					<br>
					<label for="iLoc" id="iLocat" style="margin-top: 20px;">Item Location</label>
				</div>
				<div class="col-lg-6" id="inputs">
					<input type="text" class="form-control" id="iNam" name="itemName" placeholder="Headrest for 770B">
					<br>
					<select name="itemVendor" class="form-control" style="margin-top: 15px;"> 
						<?php 
							//prepares flight information
							$stmt = $conn->prepare("select * from vendor;");
							$stmt->execute(); 
							//print information in option forum
							while (list($vendorid, $vendorname) = $stmt->fetch(PDO::FETCH_NUM)){
				            		echo("<option value='$vendorid'>$vendorname</option>");
							};
							echo "</select>";
				        	?>
					 <br>
					 <input type="number" step="0.01" style="margin-top: 15px;" class="form-control" id="iPrice" name="itemPrice" placeholder="999.99">
					 <br>
					 <input type="number" style="margin-top: 15px;" class="form-control" id="iHand" name="itemQty" placeholder="15">
					 <br>
					 <input type="text" style="margin-top: 15px;" class="form-control" id="iDes" name="itemDescription" placeholder="Replacement headrest for a seat in a 770B">
					 <br>
					 <select name="itemLocation" class="form-control" style="margin-top: 15px;"> 
							<?php 
								//prepares flight information
								$stmt = $conn->prepare("select * from location;");
								$stmt->execute(); 
								//print information in option forum
								while (list($locationid, $locationname) = $stmt->fetch(PDO::FETCH_NUM))
								{
					            echo("<option value='$locationid'>$locationname</option>");
								};
					        ?>
					</select>
				</div>
			</div>
			
		</div>



		<!--
	  	<div class="form-group">
	    	<label for="iNam" id="iName" >Item Name</label>
	    	<input type="text" class="form-control" id="iNam" name="itemName" placeholder="Headrest for 770B">
	  	</div>
	  	<div class="form-group">
	    	<label for="iDes" id="iDesc">Item Description</label>
	    	<input type="text" class="form-control" id="iDes" name="itemDescription" placeholder="Replacement headrest for a seat in a 770B">
	  	</div>
	  	<div class="form-group">
	    	<label for="iHand" id="iQHand">Quantity on hand</label>
	    	<input type="number" class="form-control" id="iHand" name="itemQty" placeholder="15">
	  	</div>
	  	<br>
	    <div class="form-group">
	    	<label for="vNam" id="vName">Item Vendor</label>
	    		<select name="itemVendor" class="form-control"> 
		<?php 
			//prepares flight information
			$stmt = $conn->prepare("select * from vendor;");
			$stmt->execute(); 
			//print information in option forum
			while (list($vendorid, $vendorname) = $stmt->fetch(PDO::FETCH_NUM)){
            		echo("<option value='$vendorid'>$vendorname</option>");
			};
			echo "</select>";
        	?>
	  	</div>
	  	<div class="form-group">
	    	<label for="iPrice" id="iPric">Item Price</label>
	    	<input type="number" step="0.01" class="form-control" id="iPrice" name="itemPrice" placeholder="999.99">
	  	</div>
	  	<div class="form-group">
	    	<label for="iLoc" id="iLocat">Item Location</label>
			<select name="itemLocation" class="form-control"> 
		<?php 
			//prepares flight information
			$stmt = $conn->prepare("select * from location;");
			$stmt->execute(); 
			//print information in option forum
			while (list($locationid, $locationname) = $stmt->fetch(PDO::FETCH_NUM))
			{
            echo("<option value='$locationid'>$locationname</option>");
			};
        ?>
			</select>
	  	</div>
	  	<br>
	  	<hr>
	  -->
	  	<a href="A4Items.php" class="btn btn-danger active" role="button" aria-pressed="true" id="cancel" onclick="myReturn()">Cancel</a>
	  	<button type="submit" class="btn btn-success" id="inpt">Create</button>
	  	<button type="reset" class="btn btn-warning" id="input">Clear</button>

	</form>

	<script type="text/javascript">
		function myReturn() {
			confirm("Are you sure you want to leave this page?");
		}
	</script>
	
<?php
include("logout.php");
?>
</body>
</html>

