<!DOCTYPE html>
<?php 
//connects to mySQL server
require("login.php");
include("stateDropDown.php");
 
//preps mySQL statment
$stmt = $conn->prepare("SELECT customer.id, name,  aline1, city, state, zipcode, contactPhone from customer, customer_address, address WHERE address.id=customer_address.addressid AND customer.id=customer_address.customerid AND customer_address.type='Billing';");
$stmt->execute();

function testVariable($varName, $string)
{ 
	if ((isset($_POST[$string])) && !empty($_POST[$string])){
		$varName = $_POST[$string];
	}
	else{
		$varName = "";
	}
	return $varName;
}
?>
<html>
<head>
	<title>Create New Customer</title>
	<link rel="shortcut icon" type="image/x-icon" href="favicon.ico" />
	<link href="https://fonts.googleapis.com/css?family=Abel" rel="stylesheet">
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.1/css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="A4NewCust.css">
</head>
<body>
	<nav class="navbar navbar-default">
		<div class="navbar-collapse collapse w-100 order-1 order-md-0 dual-collapse2">
			<a href="A4Home.html" class="navbar-left"><img src="icon.png" id="icon"></a>
      		<ul class="nav navbar-nav">
				<li><a href="A4Home.html" id="home">Dashboard</a></li>
    		</ul>
    		<ul class="nav navbar-nav navbar-right">
        		<li><a href="A4Login.html" id="log">Logoff</a></li>
    		</ul>
   		</div>
	</nav>

	<h1>Create New Customer</h1>
	<?php 
	//preps the input statements
	$cName = ""; $cName = testVariable($cName, "cName");
	$baline = ""; $baline = testVariable($baline, "baline1");
	$bState = ""; $bState = testVariable($bState, "bState"); 
	$bCity = ""; $bCity = testVariable($bCity, "bCity"); 
	$bZip = ""; $bZip = testVariable($bZip, "bZip");
	$saline = ""; $saline = testVariable($saline, "saline1");
	$sState = ""; $sState = testVariable($sState, "sState");
	$sCity = ""; $sCity = testVariable($sCity, "sCity");
	$sZip = ""; $sZip = testVariable($sZip, "sZip");
	$contactFirst = ""; $contactFirst = $contactFirst = testVariable($contactFirst, "contactFirst");
	$contactLast = ""; $contactLast = testVariable($contactLast, "contactLast");
	$contactPhone = "";$contactPhone = testVariable($contactPhone, "contactPhone");
	$contactEmail = "";$contactEmail = testVariable($contactEmail, "contactEmail");
	$comment = ""; $comment = testVariable($comment, "comment");
	$billingCheck = false; $billingCheck = testVariable($billingCheck, "billingCheck");
	
	//Creating INSERT STATEMENT for Customer 
	$insert = $conn->prepare("INSERT INTO customer(name, contactfirst, contactlast, contactPhone, contactemail, comments) values (:name, :contactFirst, :contactLast, :contactPhone, :contactEmail, :comments);"); 	
	//Binds values for insert statement for Customer
	$insert->bindValue(':name', $cName, PDO::PARAM_STR);
	$insert->bindValue(':contactFirst', $contactFirst, PDO::PARAM_STR); 
	$insert->bindValue(':contactFirst', $contactFirst, PDO::PARAM_STR); 
	$insert->bindValue(':contactLast', $contactLast, PDO::PARAM_STR); 
	$insert->bindValue(':contactPhone', $contactPhone, PDO::PARAM_STR); 
	$insert->bindValue(':contactEmail', $contactEmail, PDO::PARAM_STR); 
	$insert->bindValue(':comments', $comment, PDO::PARAM_STR); 
	if (!empty($_POST))
	{ 
		//boolean for insert statement
		
		$testInsert = true;
		//unless each value is filled, gets an error message
		foreach ($_POST as $key => $value)
		{ 
			if ((empty($value)) && ($key != "comment"))
			{
			//ELLY: make the text boxes turn red or something to indicate forms weren't filled in.
				echo("Error: $key is empty. Please fill $key in. <br>");
				//prevents unnecessary input statements
				$testInsert = false;
			}
		}
		if ($testInsert == true ) //if all values have been filled out.
		{
			try
			{ 
			  $insert->execute();
			  $customerID = $conn->lastInsertId(); 
			} 
			catch(PDOException $e)
			{
			  echo "Execute failed line 79: " . $e->getMessage();
			}
			
			// Enter Billing Address
			$insert = $conn->prepare("INSERT INTO address(aline1, city, zipcode, state) values (:street, :city, :zipcode, :state);"); 	
			$insert->bindValue(':street', $baline, PDO::PARAM_STR);
			$insert->bindValue(':city', $bCity, PDO::PARAM_STR); 
			$insert->bindValue(':zipcode', $bZip, PDO::PARAM_INT); 
			$insert->bindValue(':state', $bState, PDO::PARAM_STR); 
			try
				{ 
				$insert->execute();
				$billingID = $conn->lastInsertId(); 
				} 
				catch(PDOException $e)
				{
				echo "Execute failed line 97: " . $e->getMessage();
				}
				// ELLY: Success statement! You can change it if you want.
				// echo "<h2> Customer $cName has been successfully added to the database <br></h2>";
				
			//Combines billing and customer accounts
			$insert = $conn->prepare("INSERT INTO customer_address VALUES (:custID, :addressID, :type);");
			$insert->bindValue(':custID', $customerID, PDO::PARAM_INT); 
			$insert->bindValue(':addressID', $billingID, PDO::PARAM_INT); 
			$insert->bindValue(':type', "Billing", PDO::PARAM_STR); 
			try
				{ 
				$insert->execute();
				} 
				catch(PDOException $e)
				{
				echo "Execute failed line 112: " . $e->getMessage();
				}
			
		
			if (($billingCheck == "checked"))
			{//If billing and shipping are the same, just connects the same address to two 
			//customer_address tuples
			$insert = $conn->prepare("INSERT INTO customer_address VALUES (:custID, :addressID, :type);");
			$insert->bindValue(':custID', $customerID, PDO::PARAM_INT); 
			$insert->bindValue(':addressID', $billingID, PDO::PARAM_INT); 
			$insert->bindValue(':type', "Shipping", PDO::PARAM_STR); 
			try
				{ 
				$insert->execute();
				} 
				catch(PDOException $e)
				{
				echo "Execute failed line 147: " . $e->getMessage();
				}
			} 	
			else 
			{ //Creates as shipping address and inserts a new tuple
				$insert = $conn->prepare("INSERT INTO address(aline1, city, zipcode, state) values (:street, :city, :zipcode, :state);"); 	
				$insert->bindValue(':street', $saline, PDO::PARAM_STR);
				$insert->bindValue(':city', $sCity, PDO::PARAM_STR); 
				$insert->bindValue(':zipcode', $sZip, PDO::PARAM_INT); 
				$insert->bindValue(':state', $sState, PDO::PARAM_STR);
		
				try
					{ 
					$insert->execute();
					$shippingID = $conn->lastInsertId(); 
					} 
					catch(PDOException $e)
					{
					echo "Execute failed line 97: " . $e->getMessage();
					}
				
				$insert = $conn->prepare("INSERT INTO customer_address VALUES (:custID, :addressID, :type);");
				$insert->bindValue(':custID', $customerID, PDO::PARAM_INT); 
				$insert->bindValue(':addressID', $shippingID, PDO::PARAM_INT); 
				$insert->bindValue(':type', "Shipping", PDO::PARAM_STR); 
				$insert->execute();
			}
			// ELLY: Success statement! You can change it if you want.
			echo "<h2> Customer $cName has been successfully added to the database <br></h2>";
		} 
	}
	
?>
<form class="form-inline" action="A4NewCust.php" method="post">
	<div class="container">
		<div class="row">
			<div class="col-sm-2" id="labels1">
				<label for="cName" style="margin-bottom: 20px; margin-top: 5%;">Company Name</label>
				<label for="bSt" id="bAdd" style="margin-bottom: 25px; margin-top: 12px;">Billing Street Address</label>
				<label for="bCity" id="biCity" style="margin-bottom: 25px; margin-top: 10px;">Billing City</label>
				<br>
				<label for="bState" id="biState" style="margin-bottom: 25px; margin-top: 9px;">Billing State</label>
				<br>
				<label for="bZip" id="biZip" style="margin-bottom: 25px; margin-top: 10px;">Billing Zip</label>
				
			</div>
			<div class="col-lg-3" id="inptfld1">
				<div class="form-group">
	    			<input type="text" class="form-control" id="cName" name="cName" placeholder="Airliner Industries">
	  			</div>
	  			<br>
	  			<div class="form-group">
	  				<input type="text" style="margin-top: 15px;" class="form-control" id="bSt" name = "baline1" placeholder="123 North Avenue" >
	  			</div>
	  			<br>
	  			<div class="form-group">
			  		<input type="text" style="margin-top: 15px;" class="form-control" id="bCity" name = "bCity" placeholder="Atlanta">
			  	</div>
			  	<br>
			  	<div class="form-group">
				<select class="form-control" style="margin-top: 15px;" id="bState" name="bState">
					<option value="">N/A</option>
					<option value="AK">Alaska</option>
					<option value="AL">Alabama</option>
					<option value="AR">Arkansas</option>
					<option value="AZ">Arizona</option>
					<option value="CA">California</option>
					<option value="CO">Colorado</option>
					<option value="CT">Connecticut</option>
					<option value="DC">District of Columbia</option>
					<option value="DE">Delaware</option>
					<option value="FL">Florida</option>
					<option value="GA">Georgia</option>
					<option value="HI">Hawaii</option>
					<option value="IA">Iowa</option>
					<option value="ID">Idaho</option>
					<option value="IL">Illinois</option>
					<option value="IN">Indiana</option>
					<option value="KS">Kansas</option>
					<option value="KY">Kentucky</option>
					<option value="LA">Louisiana</option>
					<option value="MA">Massachusetts</option>
					<option value="MD">Maryland</option>
					<option value="ME">Maine</option>
					<option value="MI">Michigan</option>
					<option value="MN">Minnesota</option>
					<option value="MO">Missouri</option>
					<option value="MS">Mississippi</option>
					<option value="MT">Montana</option>
					<option value="NC">North Carolina</option>
					<option value="ND">North Dakota</option>
					<option value="NE">Nebraska</option>
					<option value="NH">New Hampshire</option>
					<option value="NJ">New Jersey</option>
					<option value="NM">New Mexico</option>
					<option value="NV">Nevada</option>
					<option value="NY">New York</option>
					<option value="OH">Ohio</option>
					<option value="OK">Oklahoma</option>
					<option value="OR">Oregon</option>
					<option value="PA">Pennsylvania</option>
					<option value="PR">Puerto Rico</option>
					<option value="RI">Rhode Island</option>
					<option value="SC">South Carolina</option>
					<option value="SD">South Dakota</option>
					<option value="TN">Tennessee</option>
					<option value="TX">Texas</option>
					<option value="UT">Utah</option>
					<option value="VA">Virginia</option>
					<option value="VT">Vermont</option>
					<option value="WA">Washington</option>
					<option value="WI">Wisconsin</option>
					<option value="WV">West Virginia</option>
					<option value="WY">Wyoming</option>
				</select>
		</div>
		<br>
	  			<div class="form-group">
			  		<input type="number" style="margin-top: 15px;" class="form-control" id="bZip" name ="bZip" placeholder="12345" maxlength="5">
			  	</div>
			</div>
			<div class="col-sm-3" id="labels2">

				<label for="sSt" id="sAdd" style="margin-bottom: 25px; margin-top: 60px;">Shipping Street Address</label>
				<br>
				<label for="sCity" id="cCity" style="margin-bottom: 25px; margin-top: 9px;">Shipping City</label>
				<br>
				<label for="sState" id="state" style="margin-bottom: 25px; margin-top: 10px;">Shipping State</label>
				<br>
				<label for="sZip" id="cAdd" style="margin-bottom: 25px; margin-top:10px;">Shipping Zip</label>
			</div>
			<div class="col-lg-5" id="inptfld1">
				<div class="form-group">
	    			<input type="checkbox" style="margin-top: 10px;" id="check" name="billingCheck" value="checked" onclick="SetBilling(this.checked);"/> 
	    			<span id="checkLabel">Check if shipping address is the same as billing</span>
	  			</div>
	  			<div class="form-group">
	  				<input type="text" style="margin-top:21px;" class="form-control" id="sSt" name = "saline1" placeholder="123 North Avenue" >
	  			</div>
	  			<br>
	  			<div class="form-group">
			  		<input type="text" style="margin-top:14px;" class="form-control" id="sCity" name = "sCity" placeholder="Atlanta">
			  	</div>
			  	<br>
			  	<div class="form-group">
				<select class="form-control" style="margin-top:17px;" id="sState" name="sState">
					<option value="">N/A</option>
					<option value="AK">Alaska</option>
					<option value="AL">Alabama</option>
					<option value="AR">Arkansas</option>
					<option value="AZ">Arizona</option>
					<option value="CA">California</option>
					<option value="CO">Colorado</option>
					<option value="CT">Connecticut</option>
					<option value="DC">District of Columbia</option>
					<option value="DE">Delaware</option>
					<option value="FL">Florida</option>
					<option value="GA">Georgia</option>
					<option value="HI">Hawaii</option>
					<option value="IA">Iowa</option>
					<option value="ID">Idaho</option>
					<option value="IL">Illinois</option>
					<option value="IN">Indiana</option>
					<option value="KS">Kansas</option>
					<option value="KY">Kentucky</option>
					<option value="LA">Louisiana</option>
					<option value="MA">Massachusetts</option>
					<option value="MD">Maryland</option>
					<option value="ME">Maine</option>
					<option value="MI">Michigan</option>
					<option value="MN">Minnesota</option>
					<option value="MO">Missouri</option>
					<option value="MS">Mississippi</option>
					<option value="MT">Montana</option>
					<option value="NC">North Carolina</option>
					<option value="ND">North Dakota</option>
					<option value="NE">Nebraska</option>
					<option value="NH">New Hampshire</option>
					<option value="NJ">New Jersey</option>
					<option value="NM">New Mexico</option>
					<option value="NV">Nevada</option>
					<option value="NY">New York</option>
					<option value="OH">Ohio</option>
					<option value="OK">Oklahoma</option>
					<option value="OR">Oregon</option>
					<option value="PA">Pennsylvania</option>
					<option value="PR">Puerto Rico</option>
					<option value="RI">Rhode Island</option>
					<option value="SC">South Carolina</option>
					<option value="SD">South Dakota</option>
					<option value="TN">Tennessee</option>
					<option value="TX">Texas</option>
					<option value="UT">Utah</option>
					<option value="VA">Virginia</option>
					<option value="VT">Vermont</option>
					<option value="WA">Washington</option>
					<option value="WI">Wisconsin</option>
					<option value="WV">West Virginia</option>
					<option value="WY">Wyoming</option>
				</select>
		</div>
		<br>
	  			<div class="form-group">
			  		<input type="number" style="margin-top:15px;" class="form-control" id="sZip" name ="sZip" placeholder="12345" maxlength="5">
			  	</div>
			</div>
		</div>
		<hr>
		<div class="row">
			<div class="col-sm-2" id="conLabels">
				<label for="coName" style="margin-top:5px;">Contact First Name</label>
				<br>
				<label for="coName" style="margin-top:25px;">Contact Last Name</label>
				<br>
				<label for="coPhone" style="margin-top:25px;">Contact Phone</label>
				<br>
				<label for="coEmail" id="cEmail" style="margin-top:25px;">Contact Email</label>
			</div>
			<div class="col-lg-5">
				<input type="text" class="form-control" id="coName" name="contactFirst">
				<br>
				<input type="text" style="margin-top:15px;" class="form-control" id="coName" name="contactLast">
				<br>
				<input type="number" style="margin-top:15px;" class="form-control" id="coPhone" data-format="+1 (ddd) ddd-dddd" maxlength="10" placeholder="1234567890" name="contactPhone">
				<br>
				<input type="email" style="margin-top:15px;" class="form-control" id="coEmail" name="contactEmail" placeholder="Contact.Name@company.com">
	  	</div>
			</div>
		</div>
	</div>
			<a href="A4Customers.php" class="btn btn-danger active" role="button" aria-pressed="true" id="cancel" onclick="myReturn()">Cancel</a>
		
	  	<button type="submit" class="btn btn-success" id="inpt">Create</button>

	  	<button type="reset" class="btn btn-warning" id="input">Clear</button>
</form>
<!--
	<form class="form-inline" action="A4NewCust.php" method="post">
	  	<div class="form-group">
	    	<label for="cName">Company Name</label>
	    	<input type="text" class="form-control" id="cName" name="cName" placeholder="Airliner Industries">
	  	</div>
	  	<input type="checkbox" id="check" name="billingCheck" value="checked" onclick="SetBilling(this.checked);"/> Check if shipping address is the same as billing
	  	<br>
		<span class="border-top-0" id="billingBorder">
	  	<div class="form-group">
	  		<label for="bSt" id="bAdd">Billing Street Address</label>
	  		<input type="text" class="form-control" id="bSt" name = "baline1" placeholder="123 North Avenue" >
	  	</div>
		</span>
		<div class="form-group">
	  		<label for="sSt" id="sAdd">Shipping Street Address</label>
	  		<input type="text" class="form-control" id="sSt" name="saline1" placeholder="123 North Avenue" >
	  	</div>
		<br>
		<span class="border-top-0" id="billingBorder">  	
	  	<div class="form-group">
	  		<label for="bZip" id="biZip">Billing Zip</label>
	  		<input type="number" class="form-control" id="bZip" name ="bZip" placeholder="12345" maxlength="5">
	  	</div>
	  	<div class="form-group">
	  		<label for="bCity" id="biCity">Billing City</label>
	  		<input type="text" class="form-control" id="bCity" name = "bCity" placeholder="Atlanta">
	  	</div>
		</span>
		<div class="form-group">
			<label for="bState" id="biState">Billing State </label>
				<select class="form-control" id="bState" name="bState">
					<option value="">N/A</option>
					<option value="AK">Alaska</option>
					<option value="AL">Alabama</option>
					<option value="AR">Arkansas</option>
					<option value="AZ">Arizona</option>
					<option value="CA">California</option>
					<option value="CO">Colorado</option>
					<option value="CT">Connecticut</option>
					<option value="DC">District of Columbia</option>
					<option value="DE">Delaware</option>
					<option value="FL">Florida</option>
					<option value="GA">Georgia</option>
					<option value="HI">Hawaii</option>
					<option value="IA">Iowa</option>
					<option value="ID">Idaho</option>
					<option value="IL">Illinois</option>
					<option value="IN">Indiana</option>
					<option value="KS">Kansas</option>
					<option value="KY">Kentucky</option>
					<option value="LA">Louisiana</option>
					<option value="MA">Massachusetts</option>
					<option value="MD">Maryland</option>
					<option value="ME">Maine</option>
					<option value="MI">Michigan</option>
					<option value="MN">Minnesota</option>
					<option value="MO">Missouri</option>
					<option value="MS">Mississippi</option>
					<option value="MT">Montana</option>
					<option value="NC">North Carolina</option>
					<option value="ND">North Dakota</option>
					<option value="NE">Nebraska</option>
					<option value="NH">New Hampshire</option>
					<option value="NJ">New Jersey</option>
					<option value="NM">New Mexico</option>
					<option value="NV">Nevada</option>
					<option value="NY">New York</option>
					<option value="OH">Ohio</option>
					<option value="OK">Oklahoma</option>
					<option value="OR">Oregon</option>
					<option value="PA">Pennsylvania</option>
					<option value="PR">Puerto Rico</option>
					<option value="RI">Rhode Island</option>
					<option value="SC">South Carolina</option>
					<option value="SD">South Dakota</option>
					<option value="TN">Tennessee</option>
					<option value="TX">Texas</option>
					<option value="UT">Utah</option>
					<option value="VA">Virginia</option>
					<option value="VT">Vermont</option>
					<option value="WA">Washington</option>
					<option value="WI">Wisconsin</option>
					<option value="WV">West Virginia</option>
					<option value="WY">Wyoming</option>
				</select>
		</div>
		<div class="form-group">
	  		<label for="sZip" id="cAdd">Shipping Zip</label>
	  		<input type="number" class="form-control" id="sZip" name = "sZip" placeholder="12345" maxlength="5">
	  	</div>
	  	<div class="form-group">
	  		<label for="sCity" id="cCity">Shipping City</label>
	  		<input type="text" class="form-control" id="sCity" name = "sCity" placeholder="Atlanta">
	  	</div>
	  	<div class="form-group">
			<label for="sState" id="state">Shipping State</label>
				<select class="form-control" id="sState" name="sState">
					<option value="">N/A</option>
					<option value="AK">Alaska</option>
					<option value="AL">Alabama</option>
					<option value="AR">Arkansas</option>
					<option value="AZ">Arizona</option>
					<option value="CA">California</option>
					<option value="CO">Colorado</option>
					<option value="CT">Connecticut</option>
					<option value="DC">District of Columbia</option>
					<option value="DE">Delaware</option>
					<option value="FL">Florida</option>
					<option value="GA">Georgia</option>
					<option value="HI">Hawaii</option>
					<option value="IA">Iowa</option>
					<option value="ID">Idaho</option>
					<option value="IL">Illinois</option>
					<option value="IN">Indiana</option>
					<option value="KS">Kansas</option>
					<option value="KY">Kentucky</option>
					<option value="LA">Louisiana</option>
					<option value="MA">Massachusetts</option>
					<option value="MD">Maryland</option>
					<option value="ME">Maine</option>
					<option value="MI">Michigan</option>
					<option value="MN">Minnesota</option>
					<option value="MO">Missouri</option>
					<option value="MS">Mississippi</option>
					<option value="MT">Montana</option>
					<option value="NC">North Carolina</option>
					<option value="ND">North Dakota</option>
					<option value="NE">Nebraska</option>
					<option value="NH">New Hampshire</option>
					<option value="NJ">New Jersey</option>
					<option value="NM">New Mexico</option>
					<option value="NV">Nevada</option>
					<option value="NY">New York</option>
					<option value="OH">Ohio</option>
					<option value="OK">Oklahoma</option>
					<option value="OR">Oregon</option>
					<option value="PA">Pennsylvania</option>
					<option value="PR">Puerto Rico</option>
					<option value="RI">Rhode Island</option>
					<option value="SC">South Carolina</option>
					<option value="SD">South Dakota</option>
					<option value="TN">Tennessee</option>
					<option value="TX">Texas</option>
					<option value="UT">Utah</option>
					<option value="VA">Virginia</option>
					<option value="VT">Vermont</option>
					<option value="WA">Washington</option>
					<option value="WI">Wisconsin</option>
					<option value="WV">West Virginia</option>
					<option value="WY">Wyoming</option>
				</select>
		</div>
	<br>
	<hr>
	  	<div class="form-group">
	    	<label for="coName">Contact First Name</label>
	    	<input type="text" class="form-control" id="coName" name="contactFirst">
	  	</div>
		<div class="form-group">
	    	<label for="coName">Contact Last Name</label>
	    	<input type="text" class="form-control" id="coName" name="contactLast">
	  	</div>
	  	<div class="form-group">
	    	<label style="margin-left: 63px;"  for="comment" id="comLabel">Comments</label>
	    	<textarea style="margin-left: 63px;width 200px;"  class="form-control" rows="4" id="comment" name ="comment" maxlength="275" placeholder="275 characters max"></textarea>
	  	</div>
	  	<br>
	  	<div class="form-group">
	    	<label for="coPhone">Contact Phone</label>
	    	<input type="number" class="form-control" id="coPhone" data-format="+1 (ddd) ddd-dddd" maxlength="10" placeholder="1234567890" name="contactPhone">
	  	</div>
	  	<br>
	  	<div class="form-group">
	    	<label for="coEmail">Contact Email</label>
	    	<input type="email" class="form-control" id="coEmail" name="contactEmail" placeholder="Contact.Name@company.com">
	  	</div>
		<br>
		<hr>
		<a href="A4Customers.php" class="btn btn-danger active" role="button" aria-pressed="true" id="cancel" onclick="myReturn()">Cancel</a>
		
	  	<button type="submit" class="btn btn-success" id="inpt">Create</button>

	  	<button type="reset" class="btn btn-warning" id="input">Clear</button>
-->
	<script type="text/javascript">
		function SetBilling(checked) 
			{  
          		if (checked) 
          			{  
                    	document.getElementById('sSt').value = document.getElementById('bSt').value;   
  						document.getElementById('sCity').value = document.getElementById('bCity').value;
                    	document.getElementById('sState').value = document.getElementById('bState').value;   
                    	document.getElementById('sZip').value = document.getElementById('bZip').value;   
         	 		}
         	 	else 
         	 		{  
                    	document.getElementById('sSt').value = '';   
                    	document.getElementById('sCity').value = '';   
                    	document.getElementById('sState').value = '';   
                    	document.getElementById('sZip').value = '';     
          			}
          	}  
	</script>

	<script type="text/javascript">
	function myReturn() {
		confirm("Are you sure you want to leave this page?");
	}
	</script>

<?php
include("logout.php");
?>
</body>
</html>
