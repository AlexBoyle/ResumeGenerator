<!DOCTYPE html>
<html>
<?php 
//connects to mySQL server
require("login.php"); 

//preps mySQL statment
$stmt = $conn->prepare("SELECT customerorder.id, customerorder.date, customerorder.totalPrice, customer.name, COUNT(item_line.customerorderid) AS 'Item Number' FROM customer, customerorder, item_line WHERE customerorder.customerid = customer.id AND customerorder.statusindicator='Released for Pick' AND item_line.customerorderid = customerorder.id GROUP BY customerorder.id;");
$stmt->execute();
?>
<head>
	<title>Generate a pick report</title>
	<link href="https://fonts.googleapis.com/css?family=Abel" rel="stylesheet">
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.1/css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="A4PickRep.css">
	<link rel="shortcut icon" type="image/x-icon" href="favicon.ico" />
</head>
<body>
	<nav class="navbar navbar-default">
		<div class="navbar-collapse collapse w-100 order-1 order-md-0 dual-collapse2">
			<a href="A4Home.html" class="navbar-left"><img src="icon.png" id="icon"></a>
      		<ul class="nav navbar-nav">
				<li><a href="A4Home.html" id="home">Dashboard</a></li>
    		</ul>
    		<ul class="nav navbar-nav navbar-right">
        		<li><a href="A4Login.html" id="log">Logoff</a></li>
    		</ul>
   		</div>
	</nav>

	<h1>Generate a pick report</h1>

	<form class="form-inline" id="userForm" action="ProducePickReport.php" method="post">
	<button type="submit" class="btn btn-success" id="show" >Submit</button>
	<a href="A4Home.html" class="btn btn-danger active" role="button" aria-pressed="true" id="cancel" onclick="myReturn()">Cancel</a> 
	  	<br>
<table>
		<tr>
			<th>Select</th>
			<th> Customer Order ID </th>
			<th> Customer Name </th> 
			<th> Items in Order </th>
			<th> Total Price </th>
			<th> Order Shipping Date </th>
		</tr>
<?php 
	//creates table 
		while (list($orderID, $orderDate, $totalPrice, $customerName, $itemCount) = $stmt->fetch(PDO::FETCH_NUM))
		{
			echo ("<tr>");
			
			//Checkbox
			echo ("<td>");
			echo("<input type='checkbox' name='customerorder[]' value=$orderID >");
			echo ("</td>");
			//Order ID
			echo ("<td>");
			echo("$orderID");
			echo ("</td>");
			//Customer Name
			echo ("<td>"); 
			echo ($customerName);
			echo ("</td>");
			//Item Count
			echo ("<td>"); 
			echo ($itemCount);
			echo ("</td>");
			//Total Price
			echo ("<td>"); 
			echo ($totalPrice);
			echo ("</td>");
			//Order Shipping Date
			echo ("<td>"); 
			echo ($orderDate);
			echo ("</td>");
			
			echo("</tr>");
		}
?>
	</table>  		
	</form> 
	<br>


	
   
     


	<script type="text/javascript">
		function myReturn() {
			confirm("Are you sure you want to leave this page?");
		}
	</script>
</body>
</html>
