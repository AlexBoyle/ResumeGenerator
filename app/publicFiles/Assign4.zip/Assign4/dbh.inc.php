<?php

$dbServername = "courses";
$dbUsername = "z1768769";
$dbPassword = "1997Jul28";
$dbName = "z1768769";

$conn = mysqli_connect($dbServername, $dbUsername, $dbPassword, $dbName);